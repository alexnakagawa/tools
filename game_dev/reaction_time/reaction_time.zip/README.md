# Reaction Time Simulation

This project is still under development.

### Installation

`pip install pygame`

`pip install matplotlib`

### Specs

This game was tested on the following specs and may not work on other distributions:
* macOS High Sierra 10.13.4
* python3.6.4